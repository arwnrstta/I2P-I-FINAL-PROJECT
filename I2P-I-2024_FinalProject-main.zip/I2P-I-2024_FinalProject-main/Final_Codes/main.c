#include "game.h"
#include <allegro5/allegro.h>

int main(int argc, char **argv)
{

    startGame();
   
    return 0;
    
}
