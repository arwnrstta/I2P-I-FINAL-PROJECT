#ifndef setting_scene_h
#define setting_scene_h

#include "utility.h"

Scene create_setting_scene(void);

#endif /* setting_scene_h */
